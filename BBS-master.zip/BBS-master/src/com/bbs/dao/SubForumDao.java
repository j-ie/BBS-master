package com.bbs.dao;

import com.bbs.model.SubForum;

public interface SubForumDao {

	public abstract void save(SubForum transientInstance);

}