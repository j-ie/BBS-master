package com.bbs.dao;

import com.bbs.model.Followcard;

public interface FollowcardDao {

	public abstract void save(Followcard followcard);

}