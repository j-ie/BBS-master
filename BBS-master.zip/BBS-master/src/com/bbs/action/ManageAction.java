package com.bbs.action;

public class ManageAction extends BaseAction{
	

}
