package com.bbs.service;

import com.bbs.model.SubForum;

public interface SubForumBiz {
	public  void add(SubForum transientInstance);
}
