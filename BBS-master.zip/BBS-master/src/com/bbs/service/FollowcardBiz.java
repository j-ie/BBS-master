package com.bbs.service;

import com.bbs.model.Followcard;

public interface FollowcardBiz {

	public abstract void addReply(Followcard followcard);

}