# BBS

JavaEE课程设计BBS技术论坛
##3月26日更新记录
1、增设我的帖子界面<br/>
2、提供上传头像，信息修改<br/>
3、增加帖子回复界面，美化回复框<br/>
4、修改板块联动，改善发帖功能<br/>

![zhangjianhao](https://github.com/zhangjianhao/BBS/blob/master/screenshot/1.png)<br/>
![zhangjianhao](https://github.com/zhangjianhao/BBS/blob/master/screenshot/2.png)<br/>
![zhangjianhao](https://github.com/zhangjianhao/BBS/blob/master/screenshot/3.png)<br/>

